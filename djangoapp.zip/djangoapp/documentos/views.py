# Bibliotecas/funções python 
from django.views.generic import CreateView, ListView
from django.urls  import reverse_lazy

# Importe locais
from documentos.models import EnviarDocumentoModel
from documentos.forms import EnviardocumentoForms

class EnviarDocumentos(CreateView):
    model = EnviarDocumentoModel
    form_class = EnviardocumentoForms
    template_name = 'enviar_documento.html'
    success_url = reverse_lazy('documentos:lista_documentos')

class ListaDocumentos(ListView):
    model = EnviarDocumentoModel
    template_name = 'lista_documentos.html'
    ordering = ['titulo']
    # paginate_by = None
    # context_object_name = object_list