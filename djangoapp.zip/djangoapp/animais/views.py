# Importações de Bibliotecas/funções 
from django.views.generic import ListView, UpdateView, DeleteView, CreateView, View
from django.urls  import reverse_lazy
import pandas as pd
from django.http import HttpResponse
from django.db.models import Q
from django.shortcuts import get_object_or_404

# Importações locais
from animais import urls
from animais.models import TanqueModels, AnimaisModels
from animais.forms import TanqueForms, AnimaisForms

class Dashboard(ListView):
    model = TanqueModels
    template_name = 'tanques/dashboard.html'
    ordering = ['nome']
    # paginate_by = None
    # context_object_name = object_list
    
    def get_queryset(self):
        queryset = super().get_queryset()
        busca = self.request.GET.get("q")

        if busca:
            busca = busca.strip()
            queryset = queryset.filter(
                Q(nome__icontains=busca) |
                Q(tipo__icontains=busca) |
                Q(data_criacao__icontains=busca) 
            )
        return queryset
    
class CreateTanque(CreateView):
    model = TanqueModels
    form_class = TanqueForms
    success_url = reverse_lazy('animais:dashboard')
    template_name = 'tanques/form.html'
    
class UpdateTanque(UpdateView):
    model = TanqueModels
    form_class = TanqueForms
    success_url = reverse_lazy('animais:dashboard')
    template_name = 'tanques/form.html'
    
class DeleteTanque(DeleteView):
    model = TanqueModels
    success_url = reverse_lazy('animais:dashboard')
    
class CreateTableView(View):
    def get(self, request, *args, **kwargs):
        # 1. Buscar os dados do banco
        busca = request.GET.get("q")
        if busca:
            busca = busca.strip()
            queryset = TanqueModels.objects.filter(
                Q(nome__icontains=busca) |
                Q(tipo__icontains=busca) |
                Q(data_criacao__icontains=busca)
            ).values(
                'nome', 'tipo', 'volume_litros', 'temperatura_min',
                'temperatura_max', 'ph_min', 'ph_max'
            )
        else:
            queryset = TanqueModels.objects.all().values(
                'nome', 'tipo', 'volume_litros', 'temperatura_min',
                'temperatura_max', 'ph_min', 'ph_max'
            )

        # 2. Converter em DataFrame
        df = pd.DataFrame(list(queryset))

        # 3. Criar o HttpResponse configurado para Excel
        response = HttpResponse(
            content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        )
        response["Content-Disposition"] = 'attachment; filename="Tanques.xlsx"'

        # 4. Salvar o DataFrame no HttpResponse
        with pd.ExcelWriter(response, engine="openpyxl") as writer:
            df.to_excel(writer, sheet_name="Tanques", index=False)

        return response

#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++#

class ListAnimais(ListView):
    model = AnimaisModels
    template_name = 'animais/list_animais.html'
    
    def get_queryset(self):
        queryset = super().get_queryset()
        busca = self.request.GET.get("q")

        if busca:
            busca = busca.strip()
            queryset = AnimaisModels.objects.filter(
                Q(nome_comum__icontains=busca) |
                Q(tanque__nome__icontains=busca) |
                Q(tanque__data_criacao__icontains=busca) | 
                Q(nome_cientifico__icontains=busca)      
            ).values(
                'nome_comum', 'nome_cientifico', 'habitat_natural', 'tanque__nome'
            )
        return queryset
    

class CreateTableAnimais(View):   
    def get(self, request, *args, **kwargs):
        # 1. Buscar os dados do banco
        busca = request.GET.get("q")
        if busca:
            busca = busca.strip()
            queryset = AnimaisModels.objects.filter(
                Q(nome_comum__icontains=busca) |
                Q(nome_cientifico__icontains=busca) |
                Q(habitat_natural__icontains=busca) |
                Q(tanque__nome__icontains=busca) 
            ).values(
                'nome_comum', 'nome_cientifico', 'habitat_natural', 'tanque__nome'
            )
        else:
            queryset = AnimaisModels.objects.all().values(
                'nome_comum', 'nome_cientifico', 'habitat_natural', 'tanque__nome'
            )

        # 2. Converter em DataFrame
        df = pd.DataFrame(list(queryset))

        # 3. Criar o HttpResponse configurado para Excel
        response = HttpResponse(
            content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        )
        response["Content-Disposition"] = 'attachment; filename="Animais.xlsx"'

        # 4. Salvar o DataFrame no HttpResponse
        with pd.ExcelWriter(response, engine="openpyxl") as writer:
            df.to_excel(writer, sheet_name="Animais", index=False)

        return response

class ListAnimaisTanqueEspecifico(ListView):
    model = AnimaisModels
    template_name = 'animais/list_animais.html'
    
    def get_queryset(self):
        tanque_id = self.kwargs.get('pk')  # Pega o pk da URL
        return AnimaisModels.objects.filter(tanque_id=tanque_id)
    

   
class CreateAnimais(CreateView):
    model = AnimaisModels
    form_class = AnimaisForms
    success_url = reverse_lazy('animais:list_animais')
    template_name = 'animais/form.html'
    
class UpdateAnimais(UpdateView):
    model = AnimaisModels
    form_class = AnimaisForms
    success_url = reverse_lazy('animais:list_animais')
    template_name = 'animais/form.html'
    
class DeleteAnimais(DeleteView):
    model = AnimaisModels
    success_url = reverse_lazy('animais:list_animais')